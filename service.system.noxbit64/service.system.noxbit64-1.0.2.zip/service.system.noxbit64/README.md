# service.system.noxbit64
NOXBIT (LibreELEC arm 64)
