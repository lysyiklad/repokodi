﻿channels = [
'Animal Family HD',
'Animal Planet HD',
'Discovery Science HD',
'Discovery Россия HD',
'Eureka HD',
'HD-Life',
'History Россия HD',
'History2 HD',
'ID Xtra Россия',
'Nat Geo Wild HD',
'National Geographic',
'National Geographic HD',
'Outdoor channel HD',
'TLC Россия',
'Travel channel HD',
'Travel+Adventure HD',
'Viasat History',
'Viasat Nature/History HD',
'Доктор',
'Еда HD',
'Живая планета',
'Живая природа HD',
'История',
'Мама',
'Телепутешествия HD',
'2+2',
'ICTV',
'Культура',
'Мир HD',
'Планета HD',
'ТНТ HD',
'ТНТ4',
'Хабар',
'Candy HD',
'Интер',
'КВН ТВ',
'Мир HD',
'Fox Life Россия',
'Paramount Сhannel HD',
'Sony Channel',
'СТБ',
'TV 1000 Action',
'TV1000 East',
'СТС Love',
'TV1000 Русское кино',
'ViP Premiere HD',
'Дом кино',
'Дом кино Премиум HD',
'КиноПремиум HD',
'КиноТВ HD',
'Киномикс',
'Кинопоказ',
'Кинопоказ HD1',
'Кинопоказ HD2',
'Киносвидание',
'Киносемья',
'Кинохит',
'НСТ (Страшное)',
'Наш Кинороман HD',
'Канал Disney',
'Карусель',
'Мульт',
'Amedia Hit HD',
'M1',
'MTV Россия',
'RU.TV',
'Fox Россия',
]


# Paramount Comedy Россия
# VH1 Classic
# VH1 Europe
# Муз-ТВ
# Paramount Сhannel HD
# Sony Channel
# Музыка Первого
# Шансон ТВ
# TV 1000 Action
# TV1000 East
# Eurosport HD
# Kazsport
# TV1000 Русское кино
# ViP Premiere HD
# Viasat Sport HD Россия
# Дом кино
# Дом кино Премиум HD
# КХЛ HD
# Матч ТВ HD
# КиноПремиум HD
# Матч! Боец
# Матч! Наш спорт
# КиноТВ HD
# Киномикс
# Матч! Футбол 2 HD
# Морской
# Кинопоказ
# Кинопоказ HD1
# НТВ+ Наш футбол HD
# Сетанта Спорт + HD
# Кинопоказ HD2
# Киносвидание
# Сетанта Спорт HD
# Киносемья
# Кинохит
# НСТ (Страшное)
# Наш Детектив HD
# Наш Кинороман HD
# Наше новое кино
# Родное кино
# Русская комедия
# Русский детектив
# Русский иллюзион
# ТВ XXI
# Bridge HD
# Europa Plus TV
# M1
# MTV Rocks
# MTV Россия
# RU.TV
# VH1 Classic
# VH1 Europe
# Муз-ТВ
# Музыка Первого
# Eurosport HD
# Viasat Sport HD Россия
# КХЛ HD
# Матч ТВ HD
# Матч! Боец
# Матч! Наш спорт
# Матч! Футбол 2 HD
# НТВ+ Наш футбол HD
# Сетанта Спорт + HD
# Сетанта Спорт HD