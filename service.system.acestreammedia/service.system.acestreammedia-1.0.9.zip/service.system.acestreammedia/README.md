# service.system.acestreammedia
## Add-on Kodi (LibreELEC ARM)  [ACE Stream Media v.3.1.33](http://acestream.org/ru/)
