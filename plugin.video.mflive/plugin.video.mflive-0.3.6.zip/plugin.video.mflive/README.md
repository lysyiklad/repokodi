# plugin.video.mflive
Ссылки на прямые трансляции футбольных матчей (https://myfootball.top).
Ссылки Sopcast проигрываются с использованием плагина Plexus (https://github.com/tvaddonsco/program.plexus)
