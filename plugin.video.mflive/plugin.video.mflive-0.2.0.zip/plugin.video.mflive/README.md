# plugin.video.mflive
Ссылки на прямые трансляции футбольных матчей (https://myfootball.top).
Kodi 17 и выше.
Ссылки Sopcast проигрываются с использованием плагина Plexus (https://github.com/tvaddonsco/program.plexus)
