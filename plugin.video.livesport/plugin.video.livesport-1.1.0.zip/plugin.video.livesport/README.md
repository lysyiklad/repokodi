# plugin.video.livesport
Ссылки на прямые споривные трансляции (https://livesport.ws).
Ссылки Sopcast проигрываются с использованием плагина Plexus (https://github.com/tvaddonsco/program.plexus)
